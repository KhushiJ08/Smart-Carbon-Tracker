const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");

require("./jobs/environmentalCron");

const connectDB = require("./config/db");

dotenv.config();
connectDB();

const app = express();

// =========================
// Middleware
// =========================
app.use(cors());
app.use(express.json());

// =========================
// Import Routes
// =========================
const { startScheduler } = require("./services/scheduler");
const userRoutes = require("./routes/userRoutes");
const carbonRoutes = require("./routes/carbonRoutes");
const activityRoutes = require("./routes/activityRoutes");
const analyticsRoutes = require("./routes/analyticsRoutes");
const recommendationRoutes = require("./routes/recommendationRoutes");
const weatherRoutes = require("./routes/weatherRoutes");
const airQualityRoutes = require("./routes/airQualityRoutes");
const environmentRoutes = require("./routes/environmentRoutes");
startScheduler();

// =========================
// API Routes
// =========================
app.use("/api/users", userRoutes);
app.use("/api/carbon", carbonRoutes);
app.use("/api/activities", activityRoutes);
app.use("/api/analytics", analyticsRoutes);
app.use("/api/recommendations", recommendationRoutes);
app.use("/api/weather", weatherRoutes);
app.use("/api/air-quality", airQualityRoutes);
app.use("/api/environment", environmentRoutes);

// =========================
// Health Check
// =========================
app.get("/api/health", (req, res) => {
  res.status(200).json({
    status: "OK",
    message: "Smart Carbon Tracker API is running",
  });
});

// =========================
// Root Route
// =========================
app.get("/", (req, res) => {
  res.send("🌱 Smart Carbon Tracker Backend Running");
});

// =========================
// 404 Handler
// =========================
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Route not found",
  });
});

// =========================
// Start Server
// =========================
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
